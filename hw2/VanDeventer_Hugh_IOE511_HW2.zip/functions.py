"""IOE 511/MATH 562, University of Michigan
Code written by: Albert S. Berahas & Jiahao Shi


Define all the functions and calculate their gradients and Hessians, those functions include:
    (1) Rosenbrock function
    (2) Quadractic function
"""
import numpy as np

def rosen_func(x):
    """Function that computes the function value for the Rosenbrock function

    Input:
        x
    Output:
        f(x)
    """

    return (1 - x[0]) ** 2 + 100 * (x[1] - x[0] ** 2) ** 2


def rosen_grad(x):
    """Function that computes the gradient of the Rosenbrock function

    Input:
        x
    Output:
        g = nabla f(x)
    """
    grad = np.zeros(2)
    grad[0] = -2 + 2*x[0] - 400*x[0]*x[1] + 400*x[0]**3
    grad[1] = 200*(x[1] - x[0]**2)
    return grad


def rosen_Hess(x):
    """Function that computes the Hessian of the Rosenbrock function

    Input:
        x
    Output:
        H = nabla^2 f(x)
    """
    H = np.zeros((2, 2))
    H[0,0] = 2 - 400*x[1] + 1200*x[0]**2
    H[0,1] = -400*x[0]
    H[1,0] = -400*x[0]  # Hessian is symmetric
    H[1,1] = 200
    return H


def quad_func(x, A, b, c):
    """Function that computes the function value for the Quadractic function

    Input:
        x
    Output:
        f(x)
    """
    return  0.5 * x.T @ A @ x + b.T @ x + c


def quad_grad(x, A, b, c):
    """Function that computes the gradient of the Quadratic function

    Input:
        x
    Output:
        g = nabla f(x)
    """
    return  A @ x + b


def quad_Hess(x, A, b, c):
    """Function that computes the Hessian of the Quadratic function

    Input:
        x
    Output:
        H = nabla^2 f(x)
    """

    return  A