""" IOE 511/MATH 562, University of Michigan
Code written by: Albert S. Berahas & Jiahao Shi
"""
import numpy as np

def GDStep(x, f, g, problem, method, options):
    """Function that: (1) computes the GD step; (2) updates the iterate; and,
         (3) computes the function and gradient at the new iterate

    Inputs:
        x, f, g, problem, method, options
    Outputs:
        x_new, f_new, g_new, d, alpha
    """
    # Set the search direction d to be -g
    d = -g

    # determine step size
    match method.options["step_type"]:
        case "Constant":
            alpha = method.options["constant_step_size"]
            x_new = x + alpha * d
            f_new = problem.compute_f(x_new)
            g_new = problem.compute_g(x_new)

        case "Backtracking":
            # Get params
            alpha = method.options["alpha"]
            tau = method.options["tau"]
            c1 = method.options["c1"]
            # Compute step
            x_new = x + alpha * d
            f_new = problem.compute_f(x_new)
            # Backtrack
            while f_new > f + c1 * alpha * g @ d:
                alpha = tau*alpha
                x_new = x + alpha * d
                f_new = problem.compute_f(x_new)
            g_new = problem.compute_g(x_new)

        case _:
            raise ValueError("step type is not defined")
    return x_new, f_new, g_new, d, alpha

def NewtonStep(x, f, g, H, problem, method, options):
    """Function that: (1) computes the GD step; (2) updates the iterate; and, 
        (3) computes the function and gradient at the new iterate
        
    Inputs:
        x, f, g, H, problem, method, options
    Outputs: 
        x_new, f_new, g_new, h_new, d, alpha
    """
    # Compute Newton direction by solving Hd = -g
    try:
        d = np.linalg.solve(H, -g)
    except np.linalg.LinAlgError:
        # If Hessian is singular, fall back to gradient descent
        d = -g
    
    # Determine step type
    match method.options["step_type"]:
        case "Constant":
            alpha = method.options["constant_step_size"]
            x_new = x + alpha * d
            f_new = problem.compute_f(x_new)
            g_new = problem.compute_g(x_new)
            h_new = problem.compute_H(x_new)
            
        case "Backtracking":
            # Get line search parameters
            alpha = method.options["alpha"]
            tau = method.options["tau"]
            c1 = method.options["c1"]
            
            # Initial step
            x_new = x + alpha * d
            f_new = problem.compute_f(x_new)
            
            # Backtracking
            while f_new > f + c1 * alpha * g @ d:
                alpha = tau * alpha
                x_new = x + alpha * d
                f_new = problem.compute_f(x_new)
                
                # Extra max_iters
                if alpha < 1e-10:
                    break
            
            # Compute new gradient and Hessian at final point
            g_new = problem.compute_g(x_new)
            h_new = problem.compute_H(x_new)
            
        case _:
            raise ValueError("step type is not defined")
    
    return x_new, f_new, g_new, h_new, d, alpha